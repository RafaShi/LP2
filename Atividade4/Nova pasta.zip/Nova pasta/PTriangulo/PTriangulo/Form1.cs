﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double ladoA;
        double ladoB;
        double ladoC;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtLadoA_Validating(object sender, CancelEventArgs e)
        {
            if(!double.TryParse(txtLadoA.Text, out ladoA) )
            {
                MessageBox.Show("Lado inválido");
                e.Cancel = true;
            }
        }

        private void txtLadoB_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtLadoB.Text, out ladoB))
            {
                MessageBox.Show("Lado inválido");
                e.Cancel = true;
            }
        }

        private void txtLadoC_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtLadoC.Text, out ladoC))
            {
                MessageBox.Show("Lado inválido");
                e.Cancel = true;
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if(ladoA < ladoB+ladoC && ladoA > Math.Abs(ladoB-ladoC)
                && ladoB < ladoA+ladoC && ladoB > Math.Abs(ladoA-ladoC)
                && ladoC < ladoA+ladoB && ladoC > Math.Abs(ladoA - ladoB))
            {
                if(ladoA==ladoB && ladoA == ladoC)
                {
                    MessageBox.Show("Triangulo equilatero");
                }
                else if((ladoA==ladoB && ladoA!=ladoC) || (ladoB==ladoC && ladoB != ladoA))
                {
                    MessageBox.Show("Triangulo isóceles");
                }
                else
                {
                    MessageBox.Show("Triangulo escaleno");
                }
            }
            else
            {
                MessageBox.Show("Não é um triangulo");
            }
            
            
        }
        
    }
}
