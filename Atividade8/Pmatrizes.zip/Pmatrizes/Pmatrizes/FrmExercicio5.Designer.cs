﻿namespace Pmatrizes
{
    partial class FrmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVerificar5 = new System.Windows.Forms.Button();
            this.lstbxVerificar5 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnVerificar5
            // 
            this.btnVerificar5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificar5.Location = new System.Drawing.Point(221, 166);
            this.btnVerificar5.Name = "btnVerificar5";
            this.btnVerificar5.Size = new System.Drawing.Size(144, 79);
            this.btnVerificar5.TabIndex = 1;
            this.btnVerificar5.Text = "Verificar";
            this.btnVerificar5.UseVisualStyleBackColor = true;
            // 
            // lstbxVerificar5
            // 
            this.lstbxVerificar5.FormattingEnabled = true;
            this.lstbxVerificar5.Location = new System.Drawing.Point(472, 52);
            this.lstbxVerificar5.Name = "lstbxVerificar5";
            this.lstbxVerificar5.Size = new System.Drawing.Size(309, 329);
            this.lstbxVerificar5.TabIndex = 2;
            // 
            // FrmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lstbxVerificar5);
            this.Controls.Add(this.btnVerificar5);
            this.Name = "FrmExercicio5";
            this.Text = "FrmExercicio5";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnVerificar5;
        private System.Windows.Forms.ListBox lstbxVerificar5;
    }
}