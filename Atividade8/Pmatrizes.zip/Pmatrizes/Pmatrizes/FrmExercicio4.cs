﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string nome = "";
            string[] vetor = new int[10];

            for (var i = 0; i < 20; i++)
            {
                nome = Interaction.InputBox("Digite o seu nome", "nome");
                vetor[i] = nome;
                MessageBox.Show(vetot[i] + "\n");

            }
        } 

