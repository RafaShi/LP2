﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        string auxiliar = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExc1_Click(object sender, EventArgs e)
        {
            auxiliar = "";
            string saida = "";
            //criar vetor
            int[] vetor = new int[20];

            //inputBox
            //projetos > adicionar referencia > Microsoft.VisualBasic
            //using Microsoft.VisualBasic; igual a linha 10
            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1}º número", "Entrada de dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido");
                    i--;

                }
                else //invertido
                {
                    saida = vetor[i] + "\n" + saida;
                }
            }
            MessageBox.Show(saida);

            Array.Reverse(vetor);
                auxiliar = "";
                //foreach pega cada dado na ordem do grupo 
                foreach (int x in vetor)
                {
                    auxiliar += x + "\n";
                }
                MessageBox.Show(auxiliar);
            
        }

        private void btnExc2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList() { "Ana", "Andre", "Débora", "Fátima", "João", "Janete", "Otávio", "marcelo", "Pedro", "Thais" };
            lista.Remove("Otávio");

            auxiliar = "";

            foreach(string s in lista)
            {
                auxiliar+= s + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExc3_Click(object sender, EventArgs e)
        {
            int num = 20;
            double[,] notas = new double[num, 3];

            for (var aluno =0; aluno <num; aluno++)
            {
                for (var nota =0; nota<3; nota++)
                {
                    auxiliar = "";
                    auxiliar = Interaction.InputBox($"Digite a nota {nota+1} do aluno {aluno+1}");
                    double soma = 0;

                    if (!double.TryParse(auxiliar, out notas[ aluno, nota]))
                    {
                        MessageBox.Show("Dado Inválido");
                        nota--;
                    }
                    else
                    {
                        if(notas[aluno,nota]<0 || notas[aluno,nota]>10)
                        {
                            MessageBox.Show("nota inválida, nota deve estar entre 0 e 10");
                            nota--;
                        }
                    }

                }
 
            }
            string resultado = "";
            double [] media = new double [num]; 

            for (var aluno = 0; aluno < num; aluno++)
            {
                media[aluno]= (notas[aluno, 0] + notas[aluno, 1] + notas[aluno, 2]) / 3;
            }
            for (int aluno = 0; aluno < num; aluno++)
            {
                resultado += "Aluno " + (aluno + 1) + " Média " + media[aluno].ToString("N2") + "\n";
            }

            MessageBox.Show(resultado);
        }

        private void btnExc4_Click(object sender, EventArgs e)
        {
            FrmExercicio4 obj=new FrmExercicio4();
            obj.Show();
        }
    }
}
