﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            string[,] notas = new string[5, 3];
            double[,] notasOK = new double[5, 3];
           

            for (int i = 0; i < 5; i++)// mudar para 5
            {
                for (int j = 0; j < 3; j++) 
                {
                    notas[i, j] = Interaction.InputBox($"digite a nota do aluno {i + 1} do professor {j + 1}", "Entrada de dados");

                    double.TryParse(notas[i, j], out notasOK[i, j]);
                    if(notasOK[i,j] < 0.0 || notasOK[i,j] > 10.0)
                    {
                        MessageBox.Show("Número menor que 0 ou maior que 10, digite outro");
                        j--;
                    }
                }   
                
                double media = (notasOK[i, 0] + notasOK[i, 1] + notasOK[i, 2]) / 3.0;
                lstbx1.Items.Add($"O aluno {i + 1} Nota professor 1 {notasOK[i, 0].ToString("N2")} Nota professor 2 {notasOK[i, 1].ToString("N2")} Nota professor 3 {notasOK[i, 2].ToString("N2")} Média {media.ToString("N2")}");
            }

            double somaMedias = 0;
            double mediaGeral = 0;

            for(int i = 0;i < 5; i++)
            {
                for(int j = 0;j < 3; j++)
                {
                    somaMedias += notasOK[i, j];
                }
            }

            mediaGeral = somaMedias / 15.0;

            lstbx1.Items.Add(".......................\n");
            lstbx1.Items.Add($"Média geral dos alunos: {mediaGeral.ToString("N2")}");

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbx1.Items.Clear();
        }
    }
}
